import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:maps/src/features/auth/presentation/google_sign_in_page.dart';
import 'package:maps/src/features/map/repository/directions_profile.dart';
import 'package:maps/src/features/map/repository/directions_repository.dart';
import 'package:maps/src/features/map/repository/directions_route.dart';
import 'package:maps/src/features/map/repository/map_repository.dart';
import 'package:maps/src/features/map/repository/mosque.dart';
import 'package:maps/src/features/map/presentation/widgets/mosque_info_sheet.dart';
import 'package:maps/src/features/map/presentation/widgets/mosque_search_bar.dart';

const mosque = Mosque(
  name: 'Sinov masjidi',
  latitude: 41.3,
  longitude: 69.2,
  address: 'Toshkent, Sinov ko‘chasi, 12',
);
const route = DirectionsRoute(
  points: [
    RoutePoint(latitude: 41.3, longitude: 69.2),
    RoutePoint(latitude: 41.31, longitude: 69.21),
  ],
  distance: 2700,
  duration: 420,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'All named mosques and only genuine addresses survive asset loading',
    () async {
      final data =
          jsonDecode(await rootBundle.loadString('assets/mock/mock.json'))
              as Map<String, dynamic>;
      final expected = (data['elements'] as List)
          .where(
            (dynamic e) =>
                ((e['tags']?['name'] as String?)?.trim() ?? '').isNotEmpty,
          )
          .length;
      final repository = MapRepositoryImpl();
      final mosques = await repository.getMosques();
      expect(mosques.length, expected);
      expect(mosques.where((m) => m.address != null).length, greaterThan(80));
      expect(mosques.any((m) => m.address == null), isTrue);
      final order = mosques.map((m) => m.name).toList();
      await repository.getNearestMosques(latitude: 41.3, longitude: 69.2);
      expect(
        (await repository.getMosques()).map((m) => m.name).toList(),
        order,
      );
    },
  );

  test(
    'Directions decodes API distance, duration and coordinate order',
    () async {
      final repository = DirectionsRepositoryImpl(
        accessToken: 'test',
        client: MockClient((request) async {
          expect(request.url.path, contains('/driving/69.2,41.3;69.21,41.31'));
          return http.Response(
            jsonEncode({
              'routes': [
                {
                  'distance': 2700,
                  'duration': 420,
                  'geometry': {
                    'coordinates': [
                      [69.2, 41.3],
                      [69.21, 41.31],
                    ],
                  },
                },
              ],
            }),
            200,
          );
        }),
      );
      final result = await repository.getRoute(
        profile: DirectionsProfile.driving,
        fromLatitude: 41.3,
        fromLongitude: 69.2,
        toLatitude: 41.31,
        toLongitude: 69.21,
      );
      expect(result?.distance, 2700);
      expect(result?.duration, 420);
      expect(result?.points.first.latitude, 41.3);
    },
  );

  testWidgets(
    'Sheet waits for button, shows failure and retries with real route metrics',
    (tester) async {
      var calls = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MosqueInfoSheet(
              mosque: mosque,
              profile: DirectionsProfile.driving,
              onProfileChanged: (_) {},
              onRequestRoute: (profile) async {
                expect(profile, DirectionsProfile.driving);
                return ++calls == 1 ? null : route;
              },
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(calls, 0);
      expect(find.text(mosque.address!), findsOneWidget);
      await tester.ensureVisible(find.text('Marshrut'));
      await tester.tap(find.text('Marshrut'));
      await tester.pumpAndSettle();
      expect(find.textContaining('Marshrut topilmadi'), findsOneWidget);
      await tester.ensureVisible(find.text('Marshrut'));
      await tester.tap(find.text('Marshrut'));
      await tester.pumpAndSettle();
      expect(calls, 2);
      expect(find.text('2.7 km'), findsOneWidget);
      expect(find.text('7 daq'), findsOneWidget);
      expect(find.text('Xaritada ko‘rish'), findsOneWidget);
    },
  );

  testWidgets(
    'Transport change clears previous estimate without requesting a route',
    (tester) async {
      DirectionsProfile? selected;
      var calls = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MosqueInfoSheet(
              mosque: mosque,
              profile: DirectionsProfile.driving,
              initialRoute: route,
              onProfileChanged: (p) => selected = p,
              onRequestRoute: (_) async {
                calls++;
                return route;
              },
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byTooltip('Piyoda'));
      await tester.pumpAndSettle();
      expect(selected, DirectionsProfile.walking);
      expect(calls, 0);
      expect(find.text('2.7 km'), findsNothing);
      expect(find.text('Marshrut'), findsOneWidget);
    },
  );

  testWidgets('Sign-in fits a small screen and enlarged text', (tester) async {
    tester.view.physicalSize = const Size(320, 568);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      MaterialApp(
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: const TextScaler.linear(1.5)),
          child: child!,
        ),
        home: const GoogleSignInPage(),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.ensureVisible(find.text('Google orqali davom etish'));
    expect(tester.takeException(), isNull);
  });

  testWidgets('Search results scroll inside compact bounded map overlay', (
    tester,
  ) async {
    final controller = TextEditingController(text: 'Sinov');
    addTearDown(controller.dispose);
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Align(
            alignment: Alignment.topCenter,
            child: SizedBox(
              width: 320,
              height: 240,
              child: MosqueSearchBar(
                controller: controller,
                query: 'Sinov',
                results: List.filled(8, mosque),
                showResults: true,
                isLoading: false,
                onChanged: (_) {},
                onSelected: (_) {},
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.drag(find.byType(ListView), const Offset(0, -150));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });
}
